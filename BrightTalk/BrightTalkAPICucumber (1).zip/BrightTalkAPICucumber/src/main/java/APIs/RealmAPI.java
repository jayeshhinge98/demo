package APIs;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.security.SecureRandom;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.testng.Assert;

public class RealmAPI {

	private String URL;
	private HttpClient httpClient = new DefaultHttpClient();
	private HttpGet httpGet;
	private StringBuffer result = new StringBuffer();
	private HttpPost httpPost;
	private HttpResponse response;

	public RealmAPI(String url) {
		this.URL = url;
		httpGet = new HttpGet(URL);
		httpPost = new HttpPost(URL);
	}

	public HttpResponse getResponse() {
		return this.response;
	}

	private void setPost(String name, String description, String contentType) {
		String xml = "<realm name=\"" + name + "\">\n" + "<description>" + description + "</description>\n"
				+ "</realm>";
		try {
			HttpEntity entity = new ByteArrayEntity(xml.getBytes("UTF-8"));
			httpPost.setEntity(entity);
		} catch (Exception e) {
			e.printStackTrace();
		}
		httpPost.setHeader("Content-Type", contentType);
	}

	private void executeRequest(HttpPost request) throws ClientProtocolException, IOException {
		response = httpClient.execute(request);
	}

	private void executeRequest(HttpGet request) throws ClientProtocolException, IOException {
		response = httpClient.execute(request);
	}

	public void CreateRealm(String name, String description, String contentType)
			throws ClientProtocolException, IOException {
		try {
			setPost(name, description, contentType);
		} catch (Exception e) {
		}

		response = httpClient.execute(httpPost);		
	}

	public void verifyContentType(String contentType) {
		int responseCode = response.getStatusLine().getStatusCode();
		if (response != null) {
			if (responseCode == 201) {
				System.out.println("PASS: Getting Response Code 201.");
				Header conType = response.getFirstHeader("Content-Type");
				String actualContainType = conType.getValue();
				actualContainType = actualContainType.substring(actualContainType.indexOf(": ") + 1,
						actualContainType.length());
				Assert.assertEquals(actualContainType, contentType, "FAIL: The Content Type does not matches.");
				System.out.println("PASS: The Content Type verified sucessfully.");
			}
		}
	}
	

	public void verifyResponse(String name, String description, String contentType) {
		int responseCode = response.getStatusLine().getStatusCode();
		if (response != null) {
			if (responseCode == 201) {
				System.out.println("PASS: Getting Response Code 201...");
				Header conType = response.getFirstHeader("Content-Type");
				String actualContainType = conType.getValue();
				actualContainType = actualContainType.substring(actualContainType.indexOf(": ") + 1,
						actualContainType.length());
				Assert.assertEquals(actualContainType, contentType, "FAIL: The Content Type does not matches.");
				System.out.println("PASS: The Content Type verified successfully.");
				try {
					BufferedReader reader = new BufferedReader(
							new InputStreamReader(response.getEntity().getContent()));
					String line = "";
					while ((line = reader.readLine()) != null) {
						result.append(line);
						//System.out.println(result.toString());
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				String actual = result.toString();
				String actualName = actual.substring(actual.indexOf("name=\"") + 6, actual.indexOf("\"><description>"));
				Assert.assertEquals(actualName, name, "FAIL: Name doesn't matches.");
				System.out.println("PASS: Name matches.");
				String actualDescr = actual.substring(actual.indexOf("<description>") + 13,
						actual.indexOf("</description>"));
				Assert.assertEquals(actualDescr, description, "FAIL: Description doesn't matches.");
				System.out.println("PASS: Description matches.");
			} else if (responseCode == 400) {
				System.out.println("FAIL: Getting Response Code 400.");
				try {
					BufferedReader reader = new BufferedReader(
							new InputStreamReader(response.getEntity().getContent()));
					String line = "";
					while ((line = reader.readLine()) != null) {
						result.append(line);
						System.out.println(result.toString());
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				String actual = result.toString();
				String actualError = actual.substring(actual.indexOf("<code>") + 6, actual.indexOf("</code>"));

				if (actualError == "MissingRealmName") {
					System.out.println("INFO: Response for empty Realm name matches.");
				} else if (actualError == "DuplicateRealmName") {
					System.out.println("INFO: Response for duplicate Realm name matches.");
				} else if (actualError == "InvalidRealmName") {
					System.out.println("INFO: Response for max length Realm name matches.");
				} else if (actualError == "InvalidRealmDescription") {
					System.out.println("INFO: Response for max length Realm description matches.");
				} else {
					Assert.fail("FAIL: Response doesn't matches and error for request is -> " + actualError);
				}
			}
		} else {
			Assert.fail("FAIL: API Request failed.");
		}
	}

	/*
	 * int responseCode = response.getStatusLine().getStatusCode();
	 * System.out.println("INFO: Response Code: " + responseCode); try { if
	 * (responseCode == 400) { System.out.
	 * println("FAIL: POST Response is bad. With Response Code - 400.");
	 * BufferedReader reader = new BufferedReader(new
	 * InputStreamReader(response.getEntity().getContent())); String line = "";
	 * while ((line = reader.readLine()) != null) { result.append(line);
	 * System.out.println(result.toString()); }
	 * allResult.add(result.toString()); allResult.add(false);
	 * allResult.add(responseCode); allResult.add(response); } else if
	 * (responseCode == 201) {
	 * System.out.println("PASS: POST Response is Successful."); BufferedReader
	 * reader = new BufferedReader(new
	 * InputStreamReader(response.getEntity().getContent())); String line = "";
	 * while ((line = reader.readLine()) != null) { result.append(line); //
	 * System.out.println(result.toString()); }
	 * allResult.add(result.toString()); allResult.add(true);
	 * allResult.add(responseCode); allResult.add(response); } return allResult;
	 * 
	 * } catch (Exception ex) { result.append("Get Response Failed");
	 * allResult.add(result.toString()); allResult.add(false);
	 * allResult.add(responseCode); allResult.add(response); return allResult; }
	 */
	public String GetResponseForGETCall(String url) throws ClientProtocolException, IOException {
		StringBuffer result = new StringBuffer();
		HttpClient client = new DefaultHttpClient();
		HttpGet request = new HttpGet(url);
		request.setHeader("Content-Type", "application/xml");
		HttpResponse response = client.execute(request);
		// System.out.println("response - "+response.getEntity().getContent());
		int responseCode = response.getStatusLine().getStatusCode();
		System.out.println("Response Code: " + responseCode);
		try {
			if (responseCode == 200) {
				System.out.println("PASS: Get Response is Successful..");
				BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
				String line = "";
				while ((line = reader.readLine()) != null) {
					result.append(line);
					// System.out.println(result.toString());
				}
			}
			return result.toString();

		} catch (Exception ex) {
			result.append("FAIL: Get Response Failed");
			return result.toString();
		}

	}

	public String GetResponseForDELETECall(String url) throws ClientProtocolException, IOException {
		StringBuffer result = new StringBuffer();
		HttpClient client = new DefaultHttpClient();
		// String url="http://api.openweathermap.org/data/2.5/weather?q=London";
		HttpDelete request = new HttpDelete(url);
		request.setHeader("Content-Type", "application/xml");
		HttpResponse response = client.execute(request);
		// System.out.println("response - "+response.getEntity().getContent());
		int responseCode = response.getStatusLine().getStatusCode();
		System.out.println("Response Code: " + responseCode);
		try {
			if (responseCode == 204) {
				System.out.println("PASS: DELETE Response is Successfully");
				BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
				String line = "";
				while ((line = reader.readLine()) != null) {
					result.append(line);
					// System.out.println(result.toString());
				}
			}
			return result.toString();

		} catch (Exception ex) {
			result.append("Get Response Failed");
			return result.toString();
		}

	}

	public String GetResponseForPOSTCallForCreateRealm(String url, String name, String description)
			throws ClientProtocolException, IOException {
		String xml = "<realm name=\"" + name + "\">\n" + "<description>" + description + "</description>\n"
				+ "</realm>";
		StringBuffer result = new StringBuffer();
		HttpClient client = new DefaultHttpClient();

		HttpPost request = new HttpPost(url);
		HttpEntity entity = new ByteArrayEntity(xml.getBytes("UTF-8"));
		request.setEntity(entity);
		request.setHeader("Content-Type", "application/xml; charset=utf-8");
		HttpResponse response = client.execute(request);
		int responseCode = response.getStatusLine().getStatusCode();
		System.out.println("Response Code: " + responseCode);
		try {
			if (responseCode == 400) {
				System.out.println("FAIL: POST Response is bad");
				BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
				String line = "";
				while ((line = reader.readLine()) != null) {
					result.append(line);
					System.out.println(result.toString());
				}
			} else if (responseCode == 201) {
				System.out.println("PASS: POST Response is Successful.");
				BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
				String line = "";
				while ((line = reader.readLine()) != null) {
					result.append(line);
					// System.out.println(result.toString());
				}
			}
			return result.toString();

		} catch (Exception ex) {
			result.append("Get Response Failed");
			return result.toString();
		}
	}

	public String randomStringWithNo(int length) {
		String AB = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890";
		SecureRandom rnd = new SecureRandom();
		StringBuilder sb = new StringBuilder(length);
		for (int i = 0; i < length; i++)
			sb.append(AB.charAt(rnd.nextInt(AB.length())));
		return sb.toString();
	}

	public String GetResponseForGETCallForID(String url) throws ClientProtocolException, IOException {
		StringBuffer result = new StringBuffer();
		HttpClient client = new DefaultHttpClient();
		HttpGet request = new HttpGet(url);
		request.setHeader("Content-Type", "application/xml");
		HttpResponse response = client.execute(request);
		// System.out.println("response - "+response.getEntity().getContent());
		int responseCode = response.getStatusLine().getStatusCode();
		System.out.println("Response Code: " + responseCode);
		try {
			if (responseCode == 200) {
				// System.out.println("FAIL: Get Response is Successful");
				BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
				String line = "";
				while ((line = reader.readLine()) != null) {
					result.append(line);
					// System.out.println(result.toString());
				}
			} else if (responseCode == 400) {
				System.out.println("PASS: Get Response with max integer Realm ID is bad(400)");
				BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
				String line = "";
				while ((line = reader.readLine()) != null) {
					result.append(line);
					System.out.println(result.toString());
				}
			}
			return result.toString();
		} catch (Exception ex) {
			result.append("FAIL: Get Response Failed");
			return result.toString();
		}
	}

	public String GetResponseForGETCallForNonExistID(String url) throws ClientProtocolException, IOException {
		StringBuffer result = new StringBuffer();
		HttpClient client = new DefaultHttpClient();
		HttpGet request = new HttpGet(url);
		request.setHeader("Content-Type", "application/xml");
		HttpResponse response = client.execute(request);
		// System.out.println("response - "+response.getEntity().getContent());
		int responseCode = response.getStatusLine().getStatusCode();
		System.out.println("Response Code: " + responseCode);
		try {
			if (responseCode == 200) {
				// System.out.println("FAIL: Get Response is Successful");
				BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
				String line = "";
				while ((line = reader.readLine()) != null) {
					result.append(line);
					// System.out.println(result.toString());
				}
			} else if (responseCode == 404) {
				System.out.println("PASS: Get Response for not exist Realm ID is bad(404)");
				BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
				String line = "";
				while ((line = reader.readLine()) != null) {
					result.append(line);
					System.out.println(result.toString());
				}
			}
			return result.toString();
		} catch (Exception ex) {
			result.append("FAIL: Get Response Failed");
			return result.toString();
		}
	}

	public String GetResponseForPOSTCallToCreateRealm(String url, String name, String description)
			throws ClientProtocolException, IOException {
		String xml = "<realm name=\"" + name + "\">\n" + "<description>" + description + "</description>\n"
				+ "</realm>";
		StringBuffer result = new StringBuffer();
		String code = "";
		HttpClient client = new DefaultHttpClient();
		HttpPost request = new HttpPost(url);
		HttpEntity entity = new ByteArrayEntity(xml.getBytes("UTF-8"));
		request.setEntity(entity);
		request.setHeader("Content-Type", "application/xml; charset=utf-8");
		HttpResponse response = client.execute(request);
		int responseCode = response.getStatusLine().getStatusCode();
		System.out.println("Response Code: " + responseCode);
		try {
			if (responseCode == 400) {
				// System.out.println("PASS: POST Response is bad");
				BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
				String line = "";

				while ((line = reader.readLine()) != null) {
					result.append(line);
					System.out.println(result.toString());
				}
			} else if (responseCode == 201) {
				System.out.println("FAIL: POST Response is Successful.");
				BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
				String line = "";
				while ((line = reader.readLine()) != null) {
					result.append(line);
					// System.out.println(result.toString());
				}
			}
			return result.toString();

		} catch (Exception ex) {
			result.append("Get Response Failed");
			return result.toString();
		}

	}

}
