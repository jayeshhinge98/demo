package TestCases;

import APIs.RealmAPI;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.concurrent.TimeUnit;

public class CreateRealmAPI {
    RealmAPI realmAPI = new RealmAPI();
    private String url = "http://recruit01.test01.brighttalk.net:8080/user/realm";
    private String id = "";
    private String random = realmAPI.randomStringWithNo(5);
    private String name = "Test RealM - "+random;
    private String description = "Test description_"+random;

    @Test(priority = 1)
    public void CreateRealmAPI() throws IOException {

        String ExpectedString = realmAPI.GetResponseForPOSTCallForCreateRealm(url,name,description);
        id = ExpectedString.substring(ExpectedString.indexOf("?><realm id=\"")+13,ExpectedString.indexOf("?><realm id=\"")+17);
        System.out.println("id is = "+id);
        try{int i = Integer.parseInt(id);}catch (Exception e){e.printStackTrace();
            System.out.println("FAIL:");}
    }

    @Test(priority = 2)
    public void DuplicateCreateRealmAPI() throws IOException {
        String ExpectedString = realmAPI.GetResponseForDuplicatePOSTCallForCreateRealm(url,name,description);
        System.out.println("Error Response -"+ExpectedString);
    }

    @Test(priority = 3)
    public void GetRealmAPI() throws IOException {
        url = "http://recruit01.test01.brighttalk.net:8080/user/realm/"+id;
        String ExpectedString = realmAPI.GetResponseForGETCall(url);
        Document doc = Jsoup.connect(url).get();
        BufferedReader reader = new BufferedReader(new InputStreamReader(new ByteArrayInputStream(doc.toString().getBytes())));
        StringBuffer result = new StringBuffer();
        String line = "";
        while ((line = reader.readLine()) != null) {
            result.append(line.trim());
        }
        Assert.assertEquals(result.toString(),ExpectedString.toString(),"FAIL: The Responses does not matches.");
        System.out.println("PASS: Responses Matches.");
    }

    @Test(priority = 4)
    public void DELETERealmAPI() throws IOException {
        url = "http://recruit01.test01.brighttalk.net:8080/user/realm/"+id;
        realmAPI.GetResponseForDELETECall(url);
    }


}
