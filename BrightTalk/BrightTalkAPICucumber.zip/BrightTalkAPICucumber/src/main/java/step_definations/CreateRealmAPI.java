package step_definations;import java.io.BufferedReader;import java.io.ByteArrayInputStream;import java.io.IOException;import java.io.InputStreamReader;import org.jsoup.Jsoup;import org.jsoup.nodes.Document;import org.testng.Assert;import org.testng.annotations.Test;import APIs.RealmAPI;
public class CreateRealmAPI {
    RealmAPI realmAPI = new RealmAPI();
    private String url = "http://recruit01.test01.brighttalk.net:8080/user/realm";
    private String id = "";
    private String random = realmAPI.randomStringWithNo(5);
    private String name = "Test RealM - "+random;    private String emptyName = "";    private String anotherName ="Test another RealM - "+realmAPI.randomStringWithNo(5);;    private String maxName=realmAPI.randomStringWithNo(110);
    private String description = "Test description_"+random;    private String maxDescription=realmAPI.randomStringWithNo(260);    private String nonexistingRealmID="5000";

    @Test(priority = 1)
    public void CreateRealmAPIPost() throws IOException {    	System.out.println("=============================Test Case 1=====================");
        String ExpectedString = realmAPI.GetResponseForPOSTCallForCreateRealm(url,name,description);
        id = ExpectedString.substring(ExpectedString.indexOf("?><realm id=\"")+13,ExpectedString.indexOf("?><realm id=\"")+17);
        System.out.println("id is = "+id);
        try{        	int i = Integer.parseInt(id);        }        catch (Exception e){        	e.printStackTrace();
            System.out.println("FAIL: Realm Id is not generated..");            }            
    }

    @Test(priority = 2)
    public void DuplicateCreateRealmAPI() throws IOException {    	System.out.println("=============================Test Case 2=====================");    	String code="";
        String ExpectedString = realmAPI.GetResponseForPOSTCallToCreateRealm(url,name,description);        code=ExpectedString.substring(ExpectedString.indexOf("<code>")+6, ExpectedString.indexOf("</code>"));        Assert.assertEquals(code,"DuplicateRealmName","FAIL: Post response for duplicate Realm Name response doesnot matches..");        System.out.println("PASS: Post response for duplicate Realm name matches..");
    }    
    @Test(priority = 3)    public void CreateRealmAPIPostWithEmptyName() throws IOException {    	System.out.println("=============================Test Case 3=====================");    	String code="";        String ExpectedString = realmAPI.GetResponseForPOSTCallToCreateRealm(url,emptyName,description);        //System.out.println("Error Response - "+ExpectedString);        code=ExpectedString.substring(ExpectedString.indexOf("<code>")+6, ExpectedString.indexOf("</code>"));        Assert.assertEquals(code,"MissingRealmName","FAIL: Post response for empty Realm Name response doesnot matches..");        System.out.println("PASS: Post response for empty Realm name matches..");    }    @Test(priority = 4)    public void CreateRealmAPIPostWithMaxLengthName() throws IOException {    	System.out.println("=============================Test Case 4=====================");    	String code="";        String ExpectedString = realmAPI.GetResponseForPOSTCallToCreateRealm(url,maxName,description);        //System.out.println("Error Response - "+ExpectedString);        code=ExpectedString.substring(ExpectedString.indexOf("<code>")+6, ExpectedString.indexOf("</code>"));        Assert.assertEquals(code,"InvalidRealmName","FAIL: Post response with Realm Name length more than 100 response doesnot matches..");        System.out.println("PASS: Post response with Realm Name length more than 100 matches..");    }        @Test(priority = 5)    public void CreateRealmAPIPostWithMaxLengthDescription() throws IOException {    	System.out.println("=============================Test Case 5=====================");    	String code="";        String ExpectedString = realmAPI.GetResponseForPOSTCallToCreateRealm(url,anotherName,maxDescription);        System.out.println("Response - "+ExpectedString);        code=ExpectedString.substring(ExpectedString.indexOf("<code>")+6, ExpectedString.indexOf("</code>"));        Assert.assertEquals(code,"InvalidRealmDescription","FAIL: Post response with Realm description length more than 255 response doesnot matches..");        System.out.println("PASS: Post response with Realm description length more than 255 matches..");    }    
    @Test(priority = 6)
    public void GetRealmAPI() throws IOException {
    	System.out.println("=============================Test Case 6=====================");    	url = "http://recruit01.test01.brighttalk.net:8080/user/realm/"+id;
        String ExpectedString = realmAPI.GetResponseForGETCall(url);
        Document doc = Jsoup.connect(url).get();
        BufferedReader reader = new BufferedReader(new InputStreamReader(new ByteArrayInputStream(doc.toString().getBytes())));
        StringBuffer result = new StringBuffer();
        String line = "";
        while ((line = reader.readLine()) != null) {
            result.append(line.trim());
        }        //System.out.println("Result is -"+result.toString());
        Assert.assertEquals(result.toString(),ExpectedString.toString(),"FAIL: The Responses does not matches.");
        System.out.println("PASS: Get Realm Responses Matches.");
    }

    @Test(priority = 7)    public void GetRealmAPIForIdMaxLengthVerification() throws IOException {    	System.out.println("=============================Test Case 7=====================");    	//HTTP error fetching URL. Status=500,        url = "http://recruit01.test01.brighttalk.net:8080/user/realm/"+id+"52";        String ExpectedString = realmAPI.GetResponseForGETCallForID(url);        Document doc = Jsoup.connect(url).get();        BufferedReader reader = new BufferedReader(new InputStreamReader(new ByteArrayInputStream(doc.toString().getBytes())));        StringBuffer result = new StringBuffer();        String line = "";        while ((line = reader.readLine()) != null) {            result.append(line.trim());        }        System.out.println("Result is->"+result.toString());        System.out.println("Expected Result is->"+ExpectedString.toString());        Assert.assertEquals(result.toString(),ExpectedString.toString(),"FAIL: The Get Responses for max length(>9999) Realm ID does not matches.(400 Bad Request)");        System.out.println("PASS: The Get Responses for max length(>9999) Realm ID Matches.(400 Bad Request)");    }        @Test(priority = 8)    public void GetRealmAPIForNonExistingRealmID() throws IOException {    	System.out.println("=============================Test Case 8=====================");    	//HTTP error fetching URL. Status=400        url = "http://recruit01.test01.brighttalk.net:8080/user/realm/"+nonexistingRealmID;        String ExpectedString = realmAPI.GetResponseForGETCallForNonExistID(url);        Document doc = Jsoup.connect(url).get();        BufferedReader reader = new BufferedReader(new InputStreamReader(new ByteArrayInputStream(doc.toString().getBytes())));        StringBuffer result = new StringBuffer();        String line = "";        while ((line = reader.readLine()) != null) {            result.append(line.trim());        }//        System.out.println("Result is->"+result.toString());//        System.out.println("Expected Result is->"+ExpectedString.toString());        Assert.assertEquals(result.toString(),ExpectedString.toString(),"FAIL: The Get Responses for non exist Realm ID does not matches.");        System.out.println("PASS: The Get Responses for non exist Realm ID Matches.");    }    //    @Test(priority = 9)    public void DELETERealmAPI() throws IOException {        url = "http://recruit01.test01.brighttalk.net:8080/user/realm/"+id;        realmAPI.GetResponseForDELETECall(url);    }    
}
