package step_definations;
import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
//import cucumber.api.testng.AbstractTestNGCucumberTests;

@RunWith(Cucumber.class)                 
//@CucumberOptions(features="src/feature/Case_Schedule.feature" , tags ={"@Mobile_CaseSchedule_CalenderViewNavigation"}, glue = {"feature.step_definitions"})
@CucumberOptions(features="src/test/java/features/testAPI.feature" )
//@CucumberOptions(features="src/feature/Tray2Tray.feature" , tags ={"@Tray2Tray_OnePartTransfer"},glue = {"feature.step_definitions"})
public class Runner{// extends AbstractTestNGCucumberTests {

}