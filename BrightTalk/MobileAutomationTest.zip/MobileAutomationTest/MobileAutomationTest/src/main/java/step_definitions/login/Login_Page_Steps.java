package step_definitions.login;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import utilities.SuiteBase;
import actions.login.Login_Action;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Login_Page_Steps {
	public WebDriver driver;	
	public WebDriverWait wait;
	public Login_Page_Steps(){
		driver = SuiteBase.driver;
		wait = SuiteBase.wait;
	}	
	public Login_Action loginAction=new Login_Action(driver,wait);
	
	@Given("^I am on the Home Screen$")
	public void i_am_on_the_Home_Screen() throws Throwable {
		System.out.println("========================================================"+driver);
	    ///Home Page Verification
		//Assert.assertEquals(loginAction.verifyHomePage(), true, "Home Page does not load Properly..");
		Assert.assertEquals(driver.findElement(By.xpath(".//*[@id='userAuthenticationActions']/a[1]")).isDisplayed(), true);
		System.out.println("Home page load properly and verified successfully.");
	}
	@Given("^I am Logged into application$")
	public void i_am_Logged_into_application() throws Throwable {
	    
	}

	@When("^I click on Log in button$")
	public void i_click_on_Log_in_button() throws Throwable {
	  //loginAction.clickLogInButton();
	  System.out.println("Log IN button clicking");
	  driver.findElement(By.xpath(".//*[@id='userAuthenticationActions']/a[1]")).click();
	  System.out.println("Log IN button clicked");
	}

	@Then("^I should see the Log In Screen$")
	public void i_should_see_the_Log_In_Screen() throws Throwable {
		System.out.println("Log IN page displaying");
	    Assert.assertEquals(loginAction.verifyEmailField(driver), true,"Log In page does not load properly..");
	    System.out.println("Log IN page displaying properly");
	}

	@Then("^I should see the Title as Log in to BrightTALK$")
	public void i_should_see_the_Title_as_Log_in_to_BrightTALK() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Login page Title verifying");
		Assert.assertEquals(loginAction.verifyTitle(driver),"Log in to BrightTALK","Log In page does not load properly..");
		System.out.println("Login page Title verified");
	}

//	@Given("^I am on Login page$")
//	public void i_am_on_Login_page() throws Throwable {
//	    System.out.println("I am on Login page");
//	}

	@When("^I enter email address$")
	public void i_enter_email_address() throws Throwable {
		System.out.println("Entering Email address");
	    loginAction.EnterEmailAddress(driver);
	    System.out.println("Email address entered..");
	}

	@When("^I enter password$")
	public void i_enter_password() throws Throwable {
		System.out.println("Entering password");
	    loginAction.EnterPassword(driver);
	    System.out.println("Password entered");
	}

	@When("^I click on Sign In button$")
	public void i_click_on_Sign_In_button() throws Throwable {
		System.out.println("Clicking SignIN button");
	    loginAction.ClickOnLogInButton(driver);
	    System.out.println("Sign In button clicked");
	   
	}

	@Then("^I should see Main page$")
	public void i_should_see_Main_page() throws Throwable {
		System.out.println("Verifying Main Page display after login");
	    Assert.assertEquals(loginAction.verifyMainPage(driver), true,"Agent not logged in successfully");
	    System.out.println("Verified Main Page display after login");
	}

}
