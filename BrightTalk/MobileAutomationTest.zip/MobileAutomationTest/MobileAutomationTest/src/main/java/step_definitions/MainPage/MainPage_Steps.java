package step_definitions.MainPage;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import actions.MainPageActions.MainPage_Action;
import actions.login.Login_Action;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class MainPage_Steps {
	private WebDriver driver;
	private WebDriverWait wait;
	private Login_Action loginAction;
	private MainPage_Action mpa;
	
	public MainPage_Steps(WebDriver wd, WebDriverWait wait){
		this.driver = wd;
		this.wait = wait;
		loginAction =new Login_Action(this.driver, this.wait);
		mpa=new MainPage_Action(this.driver, this.wait);
	}
	
	@Given("^I am on Main Page$")
	public void i_am_on_Main_Page(){
		loginAction.verifyMainPage(driver);
	}

	@When("^I click on My channels link$")
	public void i_click_on_My_channels_link() {
	    mpa.clickOnMYChannelLink();
	}

	@When("^I click on View channel button$")
	public void i_click_on_View_channel_button(){
	    mpa.clickOnViewChannelButton();
	}

	@When("^I click on Save your seat button$")
	public void i_click_on_Save_your_seat_button(){
	    mpa.clickOnSaveYourSeat();
	}

	@Then("^I should see Seat saved success message$")
	public void i_should_see_Seat_saved_success_message() {
	  Assert.assertEquals(mpa.verifySeatSavedMessageDisplays(),true);  
	}

	@Given("^I am on Knowledge Feed Page$")
	public void i_am_on_Knowledge_Feed_Page()  {
		mpa.clickOnLogo();
	}
	
	@When("^I enter Cloud Storage In Search Field and clicked Search$")
	public void i_enter_Cloud_Storage_In_Search_Field_and_clicked_Search() {
	    mpa.searchVideo();
	}

	@Then("^I should see the list of videos with Keywords Cloud or Storage$")
	public void i_should_see_the_list_of_videos_with_Keywords_Cloud_or_Storage(){
	  Assert.assertEquals(mpa.verifySearchWorksWithVideosForKeyword(), true,"Search not working");
	}
	
}
