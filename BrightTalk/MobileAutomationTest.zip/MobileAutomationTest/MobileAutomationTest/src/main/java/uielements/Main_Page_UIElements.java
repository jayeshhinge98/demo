package uielements;

import org.openqa.selenium.By;

public class Main_Page_UIElements {
	
	public By UIElementMyChannels=By.linkText("//*[contains(text(),'My channels')]");
	public By UIElementViewChannelOne= By.xpath("//div/ul/li[1]/ul/li[6]/form/a[contains(text(),'View channel')]");
	// Button on Channel 
	public By UIElementSaveYourSeat = By.xpath("//*[contains(text(),'Save your seat')]");
	//Your place is confirmed, we'll send you email reminders
	public By UIElementConfirmationMessage = By.className("prereg-confirmation");
	public By UIElementlogo=By.className("logo");
	public By UIElementsearchButton=By.xpath(".//*[@id='searchForm']/div/button");
	public By UIElementseachField=By.id("searchField");
	public By UIElementvideoTitle=By.xpath("//*[contains(@class,'webcast-title')]");
	public By UIElementDurationUnder5Mins=By.xpath("//*[contains(text(),'Under 5 mins')]");
	
	
}
