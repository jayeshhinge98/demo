package uielements;

import org.openqa.selenium.By;

public class Login_Page_UIElements {

	public By UIElement_SignInButton = By.xpath(".//*[@id='userAuthenticationActions']/a[1]");
	public By UIElement_Email = By.id("user_login_email");
	public By UIElement_Password = By.id("user_login_password");
	public By UIElement_LogInButton = By.xpath("//*[@id='loginForm']/input");
	//Error if invalid email or password 
	//Incorrect email or password, please try again.
	public By UIElement_MainPage=By.xpath("//h1[contains(text(),'Knowledge feed')]");
}
