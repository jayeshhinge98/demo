package actions.login;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import uielements.Login_Page_UIElements;
import actions.CommonAction.CommonActions;

public class Login_Action{
	
	private WebDriver driver;
	private WebDriverWait wait;
	public Login_Action (WebDriver wd, WebDriverWait wait){
		this.driver = wd;
		this.wait = wait;
	}
	
	Login_Page_UIElements lpu=new Login_Page_UIElements();
	CommonActions ca = new CommonActions(driver,wait);	
	
	public boolean verifyHomePage () 
	{	
		System.out.println("=========Home page verification===");
		if(ca.isElementPresent(lpu.UIElement_SignInButton, driver))
		{			
			System.out.println("====Under Login Action to verify Home page");
			return true;
		}
		else
		{
			Assert.fail("Sign up page does not load properly...fail...");		
			return false;
		}
	}

	public void clickLogInButton() {
				
		if(ca.isElementPresent(lpu.UIElement_SignInButton)) {
			
			ca.performClick(lpu.UIElement_SignInButton);
			System.out.println("Sign In button clicked...");			
		}
		else 
		{
			Assert.fail("Sign In button not exist...fail...");
						
		}
	}

	public boolean verifyEmailField(WebDriver driver) {
		if(ca.isElementPresent(lpu.UIElement_Email,driver))
		{
			return true;
		}
		else
		{
			Assert.fail("Login page does not load properly...fail...");
			return false;
		}
	}

	public String verifyTitle(WebDriver driver) {
		String s=ca.getPageTitle(driver);
		return s;
	}

	public void EnterEmailAddress(WebDriver driver) {
		if(ca.isElementPresent(lpu.UIElement_Email,driver))
		{			
			ca.enterString(lpu.UIElement_Email,"amitmhetre@alohatechnology.com");
		}
		else
		{
			Assert.fail("Email field is not present...fail...");
		}
	}
	
	public boolean EnterPassword(WebDriver driver) {
		if(ca.isElementPresent(lpu.UIElement_Password,driver))
		{
			ca.enterString(lpu.UIElement_Password,"aloha@123");
			return true;
		}
		else
		{
			Assert.fail("Password field is not present...fail...");
			return false;
		}
	}

	public void ClickOnLogInButton(WebDriver driver) {
		if(ca.isElementPresent(lpu.UIElement_LogInButton,driver))
		{
			ca.performClick(lpu.UIElement_LogInButton);
		}
		else
		{
			Assert.fail("Sign In button not present...fail...");
		}
	}
	
	public boolean verifyMainPage (WebDriver driver) 
	{	
		if(ca.isElementPresent(lpu.UIElement_MainPage,driver))
		{
			return true;
		}
		else
		{
			Assert.fail("Sign up page does not load properly...fail...");
			return false;
		}
	}
}
