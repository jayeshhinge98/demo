package actions.CommonAction;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import utilities.TestUtilities;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class CommonActions {
	private WebDriver driver;
	private WebDriverWait wait;
	public CommonActions (WebDriver wd, WebDriverWait wait){
		this.driver = wd;
		this.wait = wait;
	}
	TestUtilities testu = new TestUtilities();
	private boolean acceptNextAlert = true;	

	public boolean isElementPresent(By by) {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		} finally {
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		}
	}

	public void selectDropdown(By loc, String value) {
		if (isElementPresent(loc)) {
			WebElement mySelectElm = driver.findElement(loc);
			Select mySelect = new Select(mySelectElm);
			mySelect.selectByVisibleText(value);
		} else {
			Assert.fail("Fail: Drop down locator not found.");
		}
	}

	public void performDoubleClick(By element){
//	 if(isElementPresent(element))
//	 {
//	 action.doubleClick(driver.findElement(element)).perform();
//	 }
//	 else
//	 {
//	 Assert.fail("Fail:Button not found.");
//	 }
	 }
	 
	public void performClickByMouseMove(By element){
//	 if(isElementPresent(element))
//	 {
//	 action.moveToElement(driver.findElement(element)).click().perform();
//	 }
//	 else
//	 {
//	 Assert.fail("Fail:Button not found.");
//	 }
	 }
	
	public void performClick(By element) {		
		if (isElementPresent(element)) {
			driver.findElement(element).click();
		} else {
			Assert.fail("Fail:Button not found.");
		}
	}

	public void enterString(By element, String s) {
		if (isElementPresent(element)) {
			driver.findElement(element).clear();
			driver.findElement(element).sendKeys(s);
		} else {
			Assert.fail("Fail: Text field not found.");
		}
	}

	public int randomNumber(int min, int max) {
		Random rand = new Random();
		int randomNum = rand.nextInt((max - min) + 1) + min;
		return randomNum;
	}

	public boolean isElementPresent(By by, WebDriver driver) {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		} finally {
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		}
	}

	public boolean isElementDisplayed(By loc, WebDriver driver) {
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		if (driver.findElement(loc).isDisplayed()) {
			return true;
		} else {
			return false;
		}
	}

	public boolean isElementDisplayed(WebElement loc) {
		if (loc.isDisplayed()) {
			return true;
		} else {
			return false;
		}
	}

	public boolean isElementPresent(WebElement loc, WebDriver driver) {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		try {
			loc.isDisplayed();
			return true;
		} catch (NoSuchElementException e) {
			return false;
		} catch (Exception e) {
			return false;
		} finally {
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		}
	}

	public boolean isElementPresent(By by, int time, WebDriver driver) {
		wait = new WebDriverWait(driver, time);
		driver.manage().timeouts().implicitlyWait(time, TimeUnit.SECONDS);
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(by));
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		} catch (Exception e) {
			return false;
		} finally {
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		}
	}

	public boolean isElementsPresent(By by, WebDriver driver) {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		try {
			driver.findElements(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		} catch (Exception e) {
			return false;
		} finally {
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		}
	}

	public void waitFor(int i) {
		try {
			Thread.sleep(i);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void NavigateToBackPage(WebDriver driver) {
		try {
			driver.navigate().back();
		} catch (Exception e) {

		}
	}

	public void clickOnElement(By loc, WebDriver driver, WebDriverWait wait) {
		if (isElementPresent(loc, driver)) {
			wait.until(ExpectedConditions.elementToBeClickable(loc));
			driver.findElement(loc).click();
			driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		} else {
			Assert.fail("FAIL: Location does not found..LOC-" + loc);
		}
	}

	public void clickOnElement(WebElement loc, WebDriver driver, WebDriverWait wait) {
		if (isElementPresent(loc, driver)) {
			wait.until(ExpectedConditions.elementToBeClickable(loc));
			loc.click();
			driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		} else {
			Assert.fail("FAIL: Location does not found..LOC-" + loc);
		}
	}

	public void doubleClickOnElement(By loc, WebDriver driver, WebDriverWait wait) {
		if (isElementPresent(loc, driver)) {
			wait.until(ExpectedConditions.elementToBeClickable(loc));
			Actions action = new Actions(driver).doubleClick(driver.findElement(loc));
			action.build().perform();
			driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		} else {
			Assert.fail("FAIL: Location does not found..LOC-" + loc);
		}
	}

	public void doubleClickOnElement(WebElement loc, WebDriver driver, WebDriverWait wait) {
		if (isElementPresent(loc, driver)) {
			wait.until(ExpectedConditions.elementToBeClickable(loc));
			Actions action = new Actions(driver).doubleClick(loc);
			action.build().perform();
			driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		} else {
			Assert.fail("FAIL: Location does not found..LOC-" + loc);
		}
	}

	public void rightClickOnElement(WebElement loc, WebDriver driver, WebDriverWait wait) {
		if (isElementPresent(loc, driver)) {
			wait.until(ExpectedConditions.elementToBeClickable(loc));
			Actions oAction = new Actions(driver);
			oAction.moveToElement(loc);
			oAction.contextClick(loc).build().perform();
			driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		} else {
			Assert.fail("FAIL: Location does not found..LOC-" + loc);
		}
	}

	public void rightClickOnElement(By loc, WebDriver driver, WebDriverWait wait) {
		if (isElementPresent(loc, driver)) {
			wait.until(ExpectedConditions.elementToBeClickable(loc));
			Actions oAction = new Actions(driver);
			oAction.moveToElement(driver.findElement(loc));
			oAction.contextClick(driver.findElement(loc)).build().perform();
			driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		} else {
			Assert.fail("FAIL: Location does not found..LOC-" + loc);
		}
	}

	public void clearTextBox(By loc, WebDriver driver) {
		if (isElementPresent(loc, driver)) {
			driver.findElement(loc).clear();
		} else {
			Assert.fail("FAIL: Location does not found..LOC-" + loc);
		}
	}

	public void clearTextBox(WebElement loc, WebDriver driver) {
		if (isElementPresent(loc, driver)) {
			loc.clear();
		} else {
			Assert.fail("FAIL: Location does not found..LOC-" + loc);
		}
	}

	public void enterTextInTextBox(By loc, String text, WebDriver driver, WebDriverWait wait) {
		if (isElementPresent(loc, driver)) {
			clickOnElement(loc, driver, wait);
			clearTextBox(loc, driver);
			driver.findElement(loc).sendKeys(text);
		} else {
			Assert.fail("FAIL: Location does not found..LOC-" + loc);
		}
	}

	public void enterTextInTextBox(WebElement loc, String text, WebDriver driver, WebDriverWait wait) {
		if (isElementPresent(loc, driver)) {
			clickOnElement(loc, driver, wait);
			clearTextBox(loc, driver);
			loc.sendKeys(text);
		} else {
			Assert.fail("FAIL: Location does not found..LOC-" + loc);
		}
	}

	public String getTextFromLocation(By loc, WebDriver driver) {
		if (isElementPresent(loc, driver)) {
			String text = driver.findElement(loc).getText();
			return text;
		} else {
			Assert.fail("FAIL: Location does not found..LOC-" + loc);
			return null;
		}
	}

	public String getTextFromLocations(By loc, WebDriver driver) {
		if (isElementPresent(loc, driver)) {
			String text = "";
			List<WebElement> allLoc = driver.findElements(loc);
			int count = 0;
			for (WebElement each : allLoc) {
				String temp = getTextFromLocation(each, driver);
				if (count != 0) {
					text = text + "\n" + temp;
				} else {
					text = text + temp;
				}
				count++;
			}
			return text;
		} else {
			Assert.fail("FAIL: Location does not found..LOC-" + loc);
			return null;
		}
	}

	public String getTextFromLocation(WebElement loc, WebDriver driver) {
		if (isElementPresent(loc, driver)) {
			String text = loc.getText();
			return text;
		} else {
			Assert.fail("FAIL: Location does not found..LOC-" + loc);
			return null;
		}
	}

	public String getTextFromListLocation(List<WebElement> allLoc, int no, WebDriver driver) {
		if (isElementPresent(allLoc.get(no), driver)) {
			String text = allLoc.get(no).getText();
			return text;
		} else {
			Assert.fail("FAIL: Location does not found..LOC-" + allLoc.get(no));
			return null;
		}
	}

	public String getTextFromLocationUsingAttribute(By loc, String attribute, WebDriver driver) {
		if (isElementPresent(loc, driver)) {
			String text = driver.findElement(loc).getAttribute(attribute);
			return text;
		} else {
			Assert.fail("FAIL: Location does not found..LOC-" + loc);
			return null;
		}
	}

	public String getTextFromLocationUsingAttribute(WebElement loc, String attribute, WebDriver driver) {
		if (isElementPresent(loc, driver)) {
			String text = loc.getAttribute(attribute);
			return text;
		} else {
			Assert.fail("FAIL: Location does not found..LOC-" + loc);
			return null;
		}
	}

	public String getPageTitle(WebDriver driver) {
		String title = driver.getTitle();
		return title;
	}

	public boolean compareStringWithEqualIgnoreCase(String actual, String expected) {
		if (actual.equalsIgnoreCase(expected)) {
			return true;
		} else {
			System.out.println("Expected is -" + expected + "\n" + "Actual is -" + actual);
			return false;
		}
	}

	public boolean compareStringWithEqualIgnoreCaseWithOutFailMessage(String actual, String expected) {
		if (actual.equalsIgnoreCase(expected)) {
			return true;
		} else {
			return false;
		}
	}

	public boolean stringContainsString(String subString, String mainString) {
		boolean foundMe = false;
		int max = mainString.length() - subString.length();
		checkRecursion: for (int i = 0; i <= max; i++) {
			int n = subString.length();

			int j = i;
			int k = 0;

			while (n-- != 0) {
				if (mainString.charAt(j++) != subString.charAt(k++)) {
					continue checkRecursion;
				}
			}
			foundMe = true;
			break checkRecursion;
		}
		return foundMe;
	}

	public boolean compareListContainsString(List<String> list, String str, ExtentTest logger) {
		if (list.contains(str)) {
			return true;
		} else {
			System.out.println("FAIL: List not contains string.");
			System.out.println("List data-");
			printListString(list);
			System.out.println("String is -" + str);
			logger.log(LogStatus.FAIL, "FAIL: List not contains string.");
			return false;
		}
	}

	public boolean compareListContainsStringWithOutFailMsg(List<String> list, String str) {
		if (list.contains(str)) {
			return true;
		} else {
			return false;
		}
	}

	public boolean compareStringContainsString(String actualString, String expectedContainsString, ExtentTest logger) {
		if (actualString.contains(expectedContainsString)) {
			return true;
		} else {
			System.out.println("FAIL: Actual String Does not contains expected string.");
			System.out.println("Actual String :-" + actualString);
			System.out.println("Expected Contains String :-" + expectedContainsString);
			logger.log(LogStatus.FAIL, "FAIL: Actual String Does not contains expected string.");
			return false;
		}
	}

	public boolean compareStringContainsStringWithOutFailMsg(String actualString, String expectedContainsString) {
		if (actualString.contains(expectedContainsString)) {
			return true;
		} else {
			return false;
		}
	}

	public void verifyAssertTrue(boolean condition, String passMessage, String failMessage, String methodName,
			WebDriver driver, ExtentTest logger) {
		try {
			Assert.assertTrue(condition, failMessage);
			System.out.println(passMessage);
			logger.log(LogStatus.PASS, passMessage);
		} catch (Exception e) {
			assertFailWthException(failMessage, methodName, e, driver, logger);
		}
	}

	public void verifyAssertFalse(boolean condition, String passMessage, String failMessage, String methodName,
			WebDriver driver, ExtentTest logger) {
		try {
			Assert.assertFalse(condition, failMessage);
			System.out.println(passMessage);
			logger.log(LogStatus.PASS, passMessage);
		} catch (Exception e) {
			assertFailWthException(failMessage, methodName, e, driver, logger);
		}
	}

	public void verifyAssertEqualString(String actual, String expected, String passMessage, String failMessage,
			String methodName, WebDriver driver, ExtentTest logger) {
		try {
			Assert.assertEquals(actual, expected, failMessage);
			System.out.println(passMessage);
			logger.log(LogStatus.PASS, passMessage);
		} catch (Exception e) {
			assertFailWthException(failMessage, methodName, e, driver, logger);
		}
	}

	public void verifyAssertEqualIntegers(int actual, int expected, String passMessage, String failMessage,
			String methodName, WebDriver driver, ExtentTest logger) {
		try {
			Assert.assertEquals(actual, expected, failMessage);
			System.out.println(passMessage);
			logger.log(LogStatus.PASS, passMessage);
		} catch (Exception e) {
			assertFailWthException(failMessage, methodName, e, driver, logger);
		}
	}

	public void verifyAssertNotEqualIntegers(int actual, int expected, String passMessage, String failMessage,
			String methodName, WebDriver driver, ExtentTest logger) {
		try {
			Assert.assertNotEquals(actual, expected, failMessage);
			System.out.println(passMessage);
			logger.log(LogStatus.PASS, passMessage);
		} catch (Exception e) {
			assertFailWthException(failMessage, methodName, e, driver, logger);
		}
	}

	public void verifyAssertEqualListString(List<String> actual, List<String> expected, String passMessage,
			String failMessage, String methodName, WebDriver driver, ExtentTest logger) {
		try {
			/*
			 * System.out.println("Expected list :-");
			 * printListString(expected); System.out.println("Actual List :-");
			 * printListString(actual);
			 */
			Assert.assertEquals(actual, expected, failMessage);
			System.out.println(passMessage);
			logger.log(LogStatus.PASS, passMessage);
		} catch (Exception e) {
			System.out.println("Expected list :-");
			printListString(expected);
			System.out.println("Actual List :-");
			printListString(actual);
			assertFailWthExceptionWithList(failMessage, methodName, e, actual, expected, driver, logger);
		}
	}

	public void assertFailWthException(String failMessage, String methodName, Exception e, WebDriver driver,
			ExtentTest logger) {
		String screenShot_path = testu.captureScreen(driver, testu.getReportPath(), methodName);
		String image = logger.addScreenCapture(screenShot_path);
		logger.log(LogStatus.FAIL, failMessage, image);
		e.printStackTrace();
		Assert.fail(failMessage);
	}

	public void assertFailWthExceptionWithList(String failMessage, String methodName, Exception e, List<String> actual,
			List<String> expected, WebDriver driver, ExtentTest logger) {
		String screenShot_path = testu.captureScreen(driver, testu.getReportPath(), methodName);
		String image = logger.addScreenCapture(screenShot_path);
		logger.log(LogStatus.FAIL, failMessage, image);
		e.printStackTrace();
		System.out.println("Expected list :-");
		printListString(expected);
		System.out.println("Actual List :-");
		printListString(actual);
		Assert.fail(failMessage);
	}

	public void assertFailWthOutException(String failMessage, String methodName, WebDriver driver, ExtentTest logger) {
		String screenShot_path = testu.captureScreen(driver, testu.getReportPath(), methodName);
		String image = logger.addScreenCapture(screenShot_path);
		logger.log(LogStatus.FAIL, failMessage, image);
		Assert.fail(failMessage);
	}

	public void assertFailWthOutExceptionWithOutImage(String failMessage, ExtentTest logger) {
		logger.log(LogStatus.FAIL, failMessage);
		Assert.fail(failMessage);
	}

	public boolean compareStringWithEquals(String actual, String expected) {
		if (actual.equals(expected)) {
			return true;
		} else {
			// System.out.println("Expected is - " + expected + "\n" + "Actual
			// is - " + actual);
			return false;
		}
	}

	public boolean compareIntegerWithInteger(int actual, int expected) {
		if (actual == expected) {
			return true;
		} else {
			System.out.println("Expected is - " + expected + "\n" + "Actual is - " + actual);
			return false;
		}
	}

	public boolean compareIntegerWithIntegerWithOutFailMsg(int actual, int expected) {
		if (actual == expected) {
			return true;
		} else {
			System.out.println("Expected is - " + expected + "\n" + "Actual is - " + actual);
			return false;
		}
	}

	public boolean compareIntegerWithDouble(double actual, double expected) {
		if (actual == expected) {
			return true;
		} else {
			System.out.println("Expected is - " + expected + "\n" + "Actual is - " + actual);
			return false;
		}
	}

	public boolean compareListStringWithEquals(int i, int j) {
		if (i == j) {
			return true;
		} else {
			System.out.println("Expected is - " + j + "\n" + "Actual is - " + i);
			return false;
		}
	}

	public boolean compareListStringWithEquals(List<String> actual, List<String> expected) {
		if (actual.equals(expected)) {
			return true;
		} else {
			System.out.println("Expected is - " + expected + "\n" + "Actual is - " + actual);
			return false;
		}
	}

	public boolean compareListOfListStringWithEquals(List<List<String>> actual, List<List<String>> expected) {
		if (actual.equals(expected)) {
			return true;
		} else {
			// System.out.println("Expected Object Size is - " + expected.size()
			// + "\n" + "Actual Object Size is - "+actual.size());
			System.out.println("Expected is - " + expected + "\n" + "Actual is - " + actual);
			return false;
		}
	}

	public boolean compareListOfListStringContainsAll(List<List<String>> actual, List<List<String>> expected) {
		if (actual.containsAll(expected)) {
			return true;
		} else {
			System.out.println("Expected is - " + expected + "\n" + "Actual is - " + actual);
			return false;
		}
	}

	public boolean compareListStringWithContains(List<String> actual, List<String> expected) {
		if (actual.contains(expected)) {
			return true;
		} else {
			System.out.println("Expected is - " + expected + "\n" + "Actual is - " + actual);
			return false;
		}
	}

	public boolean compareListStringWithContainsWithOutFailMsg(List<String> actual, List<String> expected) {
		if (actual.contains(expected)) {
			return true;
		} else {
			return false;
		}
	}

	public boolean compareListStringWithContainsAll(List<String> actual, List<String> expected) {
		if (actual.containsAll(expected)) {
			return true;
		} else {
			System.out.println("Expected is - " + expected + "\n" + "Actual is - " + actual);
			return false;
		}
	}

	public void printListString(List<String> list) {
		for (String each : list) {
			System.out.println(each);
		}
	}

	public void printListInteger(List<Integer> list) {
		for (int each : list) {
			System.out.println(each);
		}
	}

	public boolean isCheckBoxSelected(By loc, String methodName, WebDriver driver, ExtentTest logger) {
		if (isElementPresent(loc, driver)) {
			if (driver.findElement(loc).isSelected()) {
				return true;
			} else {
				return false;
			}
		} else {
			logger.log(LogStatus.FAIL, "FAIL: Locator does not displayed. Loc is - " + loc);
			assertFailWthOutException("FAIL: Locator does not displayed. Loc is - " + loc, methodName, driver, logger);
			return false;
		}
	}

	public boolean isCheckBoxSelected(WebElement loc, String methodName, WebDriver driver, ExtentTest logger) {
		if (isElementPresent(loc, driver)) {
			if (loc.isSelected()) {
				return true;
			} else {
				return false;
			}
		} else {
			logger.log(LogStatus.FAIL, "FAIL: Locator does not displayed. Loc is - " + loc);
			assertFailWthOutException("FAIL: Locator does not displayed. Loc is - " + loc, methodName, driver, logger);
			return false;
		}
	}

	public boolean isFieldEnabled(By loc, String methodName, WebDriver driver, ExtentTest logger) {
		if (isElementPresent(loc, driver)) {
			if (driver.findElement(loc).isEnabled()) {
				return true;
			} else {
				return false;
			}
		} else {
			logger.log(LogStatus.FAIL, "FAIL: Locator does not displayed. Loc is - " + loc);
			assertFailWthOutException("FAIL: Locator does not displayed. Loc is - " + loc, methodName, driver, logger);
			return false;
		}
	}

	public boolean isFieldEnabled(WebElement loc, String methodName, WebDriver driver, ExtentTest logger) {
		if (isElementPresent(loc, driver)) {
			if (loc.isEnabled()) {
				return true;
			} else {
				return false;
			}
		} else {
			logger.log(LogStatus.FAIL, "FAIL: Locator does not displayed. Loc is - " + loc);
			assertFailWthOutException("FAIL: Locator does not displayed. Loc is - " + loc, methodName, driver, logger);
			return false;
		}
	}

	public void acceptAlert(WebDriver driver) {
		try {
			Alert alert = driver.switchTo().alert();
			waitFor(5000);
			alert.accept();
		} catch (org.openqa.selenium.UnhandledAlertException e) {
			Alert alert = driver.switchTo().alert();
			String alertText = alert.getText().trim();
			System.out.println("Alert data: " + alertText);
			alert.dismiss();
		} catch (NoAlertPresentException ex) {
		}
	}

	public boolean isRadioButtonSelected(By loc, String methodName, WebDriver driver, ExtentTest logger) {
		if (isElementPresent(loc, driver)) {
			if (driver.findElement(loc).isSelected()) {
				return true;
			} else {
				return false;
			}
		} else {
			logger.log(LogStatus.FAIL, "FAIL: Locator does not displayed. Loc is -" + loc);
			assertFailWthOutException("FAIL: Locator does not displayed. Loc is -" + loc, methodName, driver, logger);
			return false;
		}
	}

	public boolean isRadioButtonSelected(WebElement loc, String methodName, WebDriver driver, ExtentTest logger) {
		if (isElementPresent(loc, driver)) {
			if (loc.isSelected()) {
				return true;
			} else {
				return false;
			}
		} else {
			logger.log(LogStatus.FAIL, "FAIL: Locator does not displayed. Loc is -" + loc);
			assertFailWthOutException("FAIL: Locator does not displayed. Loc is -" + loc, methodName, driver, logger);
			return false;
		}
	}

	public List<String> addToList(List<String> actualList, String addString) {
		actualList.add(addString);
		return actualList;
	}

	public List<String> addToList(List<String> actualList, List<String> addList) {
		for (String eachString : addList) {
			actualList.add(eachString);
		}
		return actualList;
	}

	public void scrollUP(JavascriptExecutor js) {
		js.executeScript("scroll(0, -250);");
	}

	public void scrollDown(JavascriptExecutor js) {
		js.executeScript("scroll(0, 250);");
	}

	public void scrollByLine(JavascriptExecutor js) {
		js.executeScript("window.scrollByLines(2)");
	}

	public void scrollDownToElementDisplayed(JavascriptExecutor js, By loc, WebDriver driver) {
		int count = 1;
		while (count <= 10) {
			if (!driver.findElement(loc).isDisplayed()) {
				scrollDown(js);
				waitFor(1000);
			}
			count++;
		}
	}

	public void scrollUpToElementDisplayed(JavascriptExecutor js, By loc, WebDriver driver) {
		int count = 1;
		while (count <= 10) {
			if (!driver.findElement(loc).isDisplayed()) {
				scrollUP(js);
				waitFor(1000);
			}
			count++;
		}
	}

	public void swithchFrame(By loc, WebDriver driver) {
		driver.switchTo().frame(driver.findElement(loc));
		waitFor(4000);
	}

	public void swithchFrame(WebElement loc, WebDriver driver) {
		driver.switchTo().frame(loc);
		waitFor(4000);
	}

	public void switchFromFrame(WebDriver driver) {
		driver.switchTo().defaultContent();
		waitFor(2000);
	}

	public String convertListToString(List<String> list) {
		String string = "";
		int count = 0;
		for (String each : list) {
			if (count == 0) {
				string += each;
			} else {
				string += ", " + each;
			}
			count++;
		}
		return string;
	}

	public List<String> convertStringToList(String string) {
		List<String> list = new ArrayList<String>();
		if (string.contains(",")) {
			String[] stringArray = string.split(",");
			Collections.addAll(list, stringArray);
		} else {
			list.add(string);
		}
		return list;
	}

	public void focusOnElement(WebElement loc, WebDriver driver) {
		if (isElementPresent(loc, driver)) {
			loc.sendKeys("");
		} else {
			System.out.println("Locator Not found - Loc -" + loc);
		}
	}

	public void focusOnElement(By loc, WebDriver driver) {
		if (isElementPresent(loc, driver)) {
			driver.findElement(loc).sendKeys("");
			waitFor(600);
		} else {
			System.out.println("Locator Not found - Loc -" + loc);
		}
	}

	public void refreshPage(WebDriver driver) {
		waitFor(2000);
		new Actions(driver).sendKeys(Keys.F5).build().perform();
		waitFor(4000);
	}

	public void selectRandomObject(List<WebElement> loc, WebDriver driver) {
		List<WebElement> allObjectsListLoc = loc;
		Random selectObject = new Random();
		int randomObject = selectObject.nextInt(allObjectsListLoc.size());
		focusOnElement(allObjectsListLoc.get(randomObject), driver);
		allObjectsListLoc.get(randomObject).click();
		waitFor(2000);
	}

	private boolean isAlertPresent(WebDriver driver) {
	    try {
	      driver.switchTo().alert();
	      return true;
	    } catch (NoAlertPresentException e) {
	      return false;
	    }
	  }
	
	private String closeAlertAndGetItsText(WebDriver driver) {
	    try {
	      Alert alert = driver.switchTo().alert();
	      String alertText = alert.getText();
	      if (acceptNextAlert) {
	        alert.accept();
	        System.out.println("Alert Closed..");
	      } else {
	        alert.dismiss();
	      }
	      return alertText;
	    } finally {
	      acceptNextAlert = true;
	    }
	  }


}
