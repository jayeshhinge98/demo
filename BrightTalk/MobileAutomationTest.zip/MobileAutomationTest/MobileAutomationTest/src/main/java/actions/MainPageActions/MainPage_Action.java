package actions.MainPageActions;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import uielements.Main_Page_UIElements;
import actions.CommonAction.CommonActions;

public class MainPage_Action {
	private WebDriver driver;
	private WebDriverWait wait ;
	public MainPage_Action(WebDriver wd, WebDriverWait wait){
		this.driver = wd;
		this.wait = wait;
	}
	
	CommonActions ca=new CommonActions(driver, wait);
	Main_Page_UIElements mpu=new Main_Page_UIElements();
	public void clickOnMYChannelLink() {
			ca.performClick(mpu.UIElementMyChannels);		
	}
	public void clickOnViewChannelButton() {
		ca.performClick(mpu.UIElementViewChannelOne);		
	}
	public void clickOnSaveYourSeat() {
			ca.performClick(mpu.UIElementSaveYourSeat);
			System.out.println("Save your seat button clicked...");		
	}
	public boolean verifySeatSavedMessageDisplays() {
		if(ca.isElementPresent(mpu.UIElementConfirmationMessage)){
			return true;
		}
		else{
			Assert.fail("Save your seat button does not exist...fail...");
			return false;
		}
	}
	public void searchVideo() {
			ca.enterString(mpu.UIElementseachField, "Cloud Storage");
			ca.performClick(mpu.UIElementsearchButton);		
	}
	public boolean verifySearchWorksWithVideosForKeyword() {
		if(ca.isElementPresent(mpu.UIElementvideoTitle)){
			List<WebElement> options=driver.findElements(mpu.UIElementvideoTitle);	
			boolean match = false;
			//int size=options.size();
			
			for(WebElement we:options)  
			{ 			
			      if (we.getText().contains("Storage")|| we.getText().contains("Cloud")){
			    	  match = true;		    	  	    	  
			      }		      
			 }
			if(match){
				return true;
			}
			else{
				Assert.fail("List doesn't contains videos ");
				return false;
			}
		}
		else{
			return false;
		}
		
		
		
	}
	public void clickOnLogo() {
		ca.performClick(mpu.UIElementlogo);
	}
	
	
	

}
