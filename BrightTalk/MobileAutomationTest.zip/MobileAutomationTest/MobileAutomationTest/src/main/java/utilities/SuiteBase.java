package utilities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

import cucumber.api.java.After;
import cucumber.api.java.Before;

public class SuiteBase {
	public static WebDriver driver;	
	public static WebDriverWait wait;
	public static ExtentReports extent;
	public static ExtentTest logger;
	public String URL = "https://www.brighttalk.com";
	String reportPath;	
	
//	//Set extent report file path
//	@SuppressWarnings("deprecation")
//	@BeforeSuite
//	public void setUP(){			
//		//Extent report
//		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");
//		Date date = new Date();
//		String test = getClass().getSimpleName();
//		System.out.println(test);
//		String packagename = getClass().getPackage().getName();
//		packagename = packagename.replace("Tests.", "");
//		reportPath="ExtentReports\\"+ test + "-" + dateFormat.format(date) + ".html";
//		System.out.println(reportPath);
//		extent = new ExtentReports(reportPath, true);
//		extent.config().documentTitle("Automation Report").reportName(test);
//	}
//	
//	@BeforeMethod
//	public void report(Method method) {
//			String test = method.getName();
//			logger = extent.startTest("Verify " + test.replace("verify", ""));
//	}
	
	@Before
//	@Parameters("browser")
	public void openBrowserAndHitURL(){//String browser){	
//// 		For Parallel Test		
//			if(browser.equalsIgnoreCase("firefox")){
//			//create firefox instance
//				System.setProperty("webdriver.gecko.driver", "WebDrivers\\geckodriver.exe");
//				driver = new FirefoxDriver();
//			}
//			//Check if parameter passed as 'chrome'
//			else if(browser.equalsIgnoreCase("chrome")){
//				//set path to chromedriver.exe
//				System.setProperty("webdriver.chrome.driver","WebDrivers\\chromedriver.exe");
//				//create chrome instance
//				driver = new ChromeDriver();
//			}
		
    		 //Create driver
			//System.setProperty("webdriver.gecko.driver", "WebDrivers\\geckodriver.exe");
			System.setProperty("webdriver.chrome.driver", "./WebDrivers/chromedriver.exe");
			//driver = new FirefoxDriver();
			driver = new ChromeDriver();
			wait = new WebDriverWait(driver,60);
			driver.manage().window().maximize();	
			driver.get(URL);
			System.out.println("========================================================"+driver);
	}
	
//	@AfterMethod
//	public void tearDown(ITestResult result){
//			if(result.getStatus()==ITestResult.FAILURE){
//				String screenshot_path=TestUtilities.captureScreen(driver, result.getName());
//				logger.log(LogStatus.FAIL,"",screenshot_path);
//			}
//			
//	} 	
	
	@After
	public void close(){
			try{		
//				extent.endTest(logger);
//				extent.flush();
//				driver.get(reportPath);
				driver.quit();			
			}catch(Exception e){
				System.out.println("Error while closing driver"+ e);
			}
	}
	
}
