package utilities;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class TestUtilities {
	
	public static String captureScreen(WebDriver driver, String imagename) {
		
		// Get current date time with Date()
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");		
		Date date = new Date();		
		String dest = "ExtentReports//" + imagename + "-" + dateFormat.format(date) + ".jpg";		
		TakesScreenshot scrnshot=(TakesScreenshot)driver;
		File source=scrnshot.getScreenshotAs(OutputType.FILE);
		File destination=new File(dest);
		try{
		FileUtils.copyFile(source, destination);
		System.out.println("Screenshot taken");
		return dest;
		}
		catch (Exception e) {
			System.out.println("Exception while taking screenshot "+e.getMessage());
			return e.getMessage();
		}
	}

	public String getReportPath() {
		// TODO Auto-generated method stub
		return null;
	}

	public String captureScreen(WebDriver driver, String reportPath, String methodName) {
		// TODO Auto-generated method stub
		return null;
	}

	public String generateRandomString(int length) {
		return RandomStringUtils.randomAlphabetic(length);
	}

	public String generateRandomNumber(int length) {
		return RandomStringUtils.randomNumeric(length);		
	}

	public String generateRandomAlphaNumeric(int length) {
		return RandomStringUtils.randomAlphanumeric(length);
	}

	public String generateStringWithAllobedSplChars(int length,
			String allowdSplChrs) {
		String allowedChars = "abcdefghijklmnopqrstuvwxyz" + // alphabets
				"1234567890" + // numbers
				allowdSplChrs;
		return RandomStringUtils.random(length, allowedChars);
	}

}
