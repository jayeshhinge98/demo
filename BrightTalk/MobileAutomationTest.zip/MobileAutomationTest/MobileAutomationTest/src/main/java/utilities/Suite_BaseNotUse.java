package utilities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Suite_BaseNotUse {

	public static WebDriver wd=null;
	public static WebDriver wd1=null;
	public static WebDriverWait wait=null;
	
//	@BeforeClass
//	public static void launchURL() throws InterruptedException
//	{		
//		String serverURL;
//		DesiredCapabilities capabilities = new DesiredCapabilities();
//	    capabilities.setCapability("appium-version", "1.4.16.1");
//	    capabilities.setCapability("platformName", "Android");
//	    capabilities.setCapability("platform", "Android");
//	    capabilities.setCapability(CapabilityType.BROWSER_NAME,"");
//	    capabilities.setCapability("deviceName", "Nexus 5");
//	    capabilities.setCapability("platformVersion", "6.0");
//	    capabilities.setCapability("app", "C://Users//admin//Desktop//Automation//ContactManager.apk");
//	    capabilities.setCapability("app-package", "com.example.android.contactmanager");	    
//	    capabilities.setCapability("waitForAppScript", "true");
//	    capabilities.setCapability("autoAcceptAlerts", "true");	    
//	    //serverURL = new URL("http://127.0.0.1:4723/wd/hub");
//		serverURL="https://www.brighttalk.com/";
//		//wd = new AndroidDriver(serverURL, capabilities);			
//		wd=new FirefoxDriver();
//		//wd1=new ChromeDriver();
//		wait = new WebDriverWait(wd,60);
//	    wd.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
//	    Thread.sleep(10000);
//	    wd.get(serverURL);
//	}	
		
}
