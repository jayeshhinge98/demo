package Helper;

public class AppConstants {
	
	public final static String GET_REALM_URL = "http://recruit01.test01.brighttalk.net:8080/user/realm/";
	public final static String INSERT_REALM_URL = "http://recruit01.test01.brighttalk.net:8080/user/realm";
		

}
